<?php
$servername = "localhost";
$username = "markwang";
$password = "Mark@912832";
if (is_numeric($_POST['phone'])) {
	try {
    		$conn = new PDO("mysql:host=$servername;dbname=CarRegister", $username, $password);
    		// set the PDO error mode to exception
    		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    		echo "Connected successfully";
	}
	catch(PDOException $e) {
    		echo "Connection failed: " . $e->getMessage();
	}

	try {
    		$conn->exec("insert into admin_members(name,phone,password) values ('" . $_POST['name'] . "','" . $_POST['phone'] . "','" . $_POST['password'] . "')");
    		echo "add successfully";
	} 
	catch(PDOException $e) {
    		echo "add failed: " . $e->getMessage();
	}
} else {
	echo "Phone number must be digital.";
}

?>
