<?php
function isValidAdminId($id) {
        if ($id == '13910832641' ||
            $id == '18292285891' ||
            $id == '13484833819' ||
            $id == '13379396090'
        ) {
                return true;
        } else {
                return false;
        }
}

function isValidPasswd($pw) {
	if ($pw == "yly2021") {
                return true;
	} else {
                return false;
	}	
}

function isValidCookie() {
	if (!isset($_COOKIE['adminId']) || !isset($_COOKIE['passwd'])) {
                return false;
        } elseif (isValidAdminId($_COOKIE['adminId']) && isValidPasswd($_COOKIE['passwd'])) {
                return true;
	}	
	return false;
}

function isValidCarNum($car_num) {
	return strlen($car_num) > 5;
}

function showAdminOperation($conn) {
	echo "<form  action='queue.php?admin' onsubmit='return confirmAdd()' method='POST'>";
	echo "<div><span>车号(字母大写):</span> <input type='text' id='carNum' name='car_num'></div> ";
	echo "<div><span>手&emsp;&ensp;机&emsp;&ensp;号&ensp;: </span><input type='text' id='carDriver' name='driver'></div>";
	echo "<div><input type='submit' value='加入队尾'></div></form>";
	$stmt = $conn->query("SELECT * FROM queue where complete_date = '' limit 1");
        if ($row = $stmt->fetch()) {
		echo "<div><form action='queue.php?admin' onsubmit=\"return confirmExit('" . $row['car_num'] .  "')\" method='POST'>";
		echo "<input type='hidden' name='clear_head' value='finish' ><input type='submit' value='队头出队'></form></div>";
	}
}

function removeQueueHead($conn) {
	$stmt = $conn->query("SELECT * FROM queue where complete_date = '' limit 1");

        if ($row = $stmt->fetch()) {
		$stmt = $conn->query("UPDATE queue SET complete_date='" . date("Y-m-d H:i:s") . "' where id=" . $row['id']);
        } else {
		echo "排队空";
	}
}

function showQueueState($conn, $isAdmin) {
	echo "<div><input type='button' onclick = 'reload()' value='刷新'></div>";

	$stmt = $conn->query("SELECT * FROM queue where complete_date != '' order by id desc limit 3");
	$ret = $stmt->fetchAll(PDO::FETCH_ASSOC);
	$count = count($ret);

	for($i = 0; $i < $count; $i++) {
		$num = $count - $i - 1;
		$driver = "";
		if ($isAdmin) {
			$driver = "&emsp;" . $ret[$num]['driver'];
		}
                echo "<div class='completeCar'>" . ($count - $i) . ". " . $ret[$num]['car_num'] . $driver  . "&emsp;" . substr($ret[$num]['submit_date'],5) . "&emsp;" . substr($ret[$num]['complete_date'],5) . "</div>";
        }
	
	$stmt = $conn->query("SELECT * FROM queue where complete_date = ''");
	$count = 0;
        while ($row = $stmt->fetch()) {
		$count++;
		if ($isAdmin) {
			$driver = "&emsp;" . $row['driver'];
		}
                echo "<div class='waitingCar'>" . $count . ". " . $row['car_num'] . $driver . "&emsp;" . substr($row['submit_date'],5) . "&emsp;排队中</div>";
        }
	if ($count == 0) {
                echo "<div class='completeCar'>没有车在排队</div>";
	}
}

function showError($msg) {
	echo "<script>alert('" . $msg ."'); window.location.href='https://www.qiuwei.wang/CarQueue/queue.php?admin'</script>";
}
function reload($msg) {
	echo "<script>alert('" . $msg ."'); window.location.href='https://www.qiuwei.wang/CarQueue/queue.php?admin'</script>";
}
?>
