<?php
require "util.php";

$servername = "localhost";
$username = "root";
$password = "Mark@912832";

try {
    	$conn = new PDO("mysql:host=$servername;dbname=CarQueue", $username, $password);
    	// set the PDO error mode to exception
    	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
	showError("链接数据库失败: " . $e->getMessage());
	exit();
}

echo "<head>";
echo "<META HTTP-EQUIV='Pragma' CONTENT='no-cache'> <META HTTP-EQUIV='Cache-Control' CONTENT='no-cache'><META HTTP-EQUIV='Expires' CONTENT='0'>";

echo "<link rel='stylesheet' type='text/css' href='./queue.css'><script src='./queue.js'></script></head>";
$type = $_SERVER["QUERY_STRING"];
if ($type == "client") {
	echo "<h1>玉林源 - 运煤车当前排队状况</h1>";
	showQueueState($conn, false);
} else if ($type == "admin"){
	// print_r($_COOKIE['adminId']);
	if ((!isset($_COOKIE['adminId']) || empty($_COOKIE['adminId'])) && !isset( $_POST['adminId'])) {
		echo "<h1>玉林源 - 运煤车排队管理系统</h1>";
		echo "<h2>管理员登录</h2>";
		echo "<form action='queue.php?admin' novalidate method='POST'><div>手机号: <input type='text' name='adminId'></div><div>密&ensp;&ensp;码: <input type='text' name='passwd'></div><p><br><div><input type='submit' value='登陆'></div></form>";
	} elseif (!isset($_COOKIE['adminId'])) {
		if (!isValidAdminId($_POST['adminId'])) {
			showError("登录失败! 原因：手机号错误");
			exit();
		} elseif (!isset($_POST['passwd']) || !isValidPasswd($_POST['passwd'])) {
			showError("登录失败! 原因: 密码错误");
		}
		setcookie("adminId", $_POST['adminId'], time()+7*24*60*60*1000, "/CarQueue/", "www.qiuwei.wang", 1, 1);
		setcookie("passwd", $_POST['passwd'], time()+7*24*60*60*1000, "/CarQueue/", "www.qiuwei.wang", 1, 1);
		showError("登录成功！");
	} elseif (!isValidCookie()) {
		setcookie("adminId", "", time() - 100000, "/CarQueue/", "www.qiuwei.wang", 1, 1);
		setcookie("passwd", "", time() - 100000, "/CarQueue/", "www.qiuwei.wang", 1, 1);
		showError("登陆信息丢失或被篡改！重新登陆！");
	} else {
	        if (isset($_POST['clear_head'])) {
			removeQueueHead($conn);
			reload("排队完成操作成功！");
		} elseif (!isset($_POST['car_num']) || empty($_POST['car_num'])) {
		        echo "<h1>玉林源 - 运煤车排队管理系统</h1>";
			showAdminOperation($conn);
			echo "<br><div><h2>当前排队状况:</h2></div>";
	                showQueueState($conn, true);
		} elseif(!isValidCarNum($_POST['car_num'])) {
			showError("车号错误！");
		} else {
			$car_num = $_POST['car_num'];
			$operator = $_COOKIE['adminId'];
			$driver = "";
			if (isset($_POST['driver'])) {
				$driver = $_POST['driver'];
			}
			$today = date("Y-m-d H:i:s");
			try {
				$conn->exec("insert into queue(car_num,operator,driver,submit_date, complete_date) values ('" . $car_num . "','" . $operator . "','" . $driver . "','" . $today. "','')");
        			reload("添加排队操作成功！");
			} 
			catch(PDOException $e) {
        			showError("添加排队失败: " . $e->getMessage());
			}	
		}
	}
} else {
	showError("错误的地址！");
}
?>
