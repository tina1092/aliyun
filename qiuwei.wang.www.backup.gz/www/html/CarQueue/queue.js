function confirmAdd(){
	var carNum =document.getElementById("carNum").value;
	var carDriver =document.getElementById("carDriver").value;
        var re =/^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}$/;
        if(carNum.search(re) ==-1) {
    		alert("请填写正确的车牌号");
		return false;
	}

	var myreg=/^[1][3,4,5,7,8,9][0-9]{9}$/;
	if (!myreg.test(carDriver)) {
    		alert("请填写正确的手机号码");
		return false
	}
	return confirm("车号：" + carNum + " 手机号: " + carDriver + "加入排队？");
}

function confirmExit(carNum){
	return confirm("车号: '" + carNum + "'完成排队？");
}

function reload() {
	window.location.href=window.location.href;
	window.location.reload(true); 
	alert('刷新完成');
}
