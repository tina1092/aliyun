<!doctype HTML>
<html>
<head>
<link rel="stylesheet" href="https://www.qiuwei.wang/wangjiayu/style.css"/>
</head>
<h1>
<?php 

 echo "<h1> Test h1 tag with css font setting.</h1>";

?>
</h1>
</html>
